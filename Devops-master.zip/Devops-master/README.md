# DevOps

### [Ubuntu VPS Configuration](/ubuntu-vps)

### [Bind DNS Server Configuration](/bind)

### [Apache Server Configuration](/apache)

### [Nginx Server Configuration](/nginx)

### [Git Install](/git-install)

### [Php & phpmyadmin install](/php-myadmin)

### [Systemd Service Configuration](/systemd)

### [UFW Configuration](/ufw)

### [SSH Configuration](/ssh)
# SSH Configuration

##### SSH Tunnel:

`ssh <username>@<remote_ip> -L <local_port>:localhost:<remote_port>`

# Git Install:

##### git install flow

`sudo apt install git`

##### Zip & Unzip install

`sudo apt install zip unzip`